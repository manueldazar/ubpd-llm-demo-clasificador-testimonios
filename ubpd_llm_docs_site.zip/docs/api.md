---
layout: default
title: API – UBPD LLM Classifier
---

# API

This page can document how to use the Python API exposed by the project.

Example sections:

- `classify_document(text: str) -> dict`
- Expected JSON schema of the response.
- Error handling and logging.
