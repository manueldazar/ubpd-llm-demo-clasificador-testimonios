# UBPD LLM Docs Site

This folder contains a ready-to-use GitHub Pages / Jekyll docs site
for the UBPD LLM testimonial classifier project.

- Sidebar layout
- Cayman theme
- Favicon and logo (SVG)
- Docs pages under `docs/`
